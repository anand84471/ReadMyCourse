from Bio import Entrez
from Bio import SeqIO
Entrez.email = "akr.cpibtc@gmail.com"
handle = Entrez.efetch(db="nucleotide", id="AY851612", rettype="gb", retmode="text")
print(SeqIO.read(handle,"gb"))