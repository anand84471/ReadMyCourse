from Bio import Entrez, SeqIO
Entrez.email = "akr.cpibtc@gmail.com"
# handler = Entrez.efetch(db="nucleotide", id="AY851612", rettype="gb", retmode="text")
# print(handler.read())


handle = Entrez.esearch(db="nucleotide", retstart=12,retmax=1000, term="BRCA" , idtype="acc")
record = Entrez.read(handle)
#record will be a dictionary
#ids are present as the key


print(record["Count"])
print(record["RetMax"])
print(record['IdList'])
# file=open("accession_ids.txt","w")
# for accession_ids in record['IdList']:
#     file.write(accession_ids+"\n")
# file.close()
restriction_enzyme_site="ATGAAA"
count=0


for accession_ids in record["IdList"]:
    count+=1
    print("Progress...",count)
    try:
        acc_id_info=Entrez.efetch(db="nucleotide", id=accession_ids, rettype="gb", retmode="text")
        seq_record=SeqIO.read(acc_id_info,"gb")
        for features in seq_record.features:
            if features.type=="CDS":
                if features.extract(seq_record.seq).find(restriction_enzyme_site)!=-1:
                    print("restriction enzyme site is present in the gene",features.qualifiers["gene"], accession_ids)
                    break
    except:
        print("Some error occured while querying to the NCBI Database for accession id:",accession_ids)
handle.close()
